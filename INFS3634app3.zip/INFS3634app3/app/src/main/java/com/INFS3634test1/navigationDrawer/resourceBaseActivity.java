package com.INFS3634test1.navigationDrawer;

import android.support.v7.app.AppCompatActivity;

public class resourceBaseActivity extends AppCompatActivity {
    private static final String TAG = "resourceBaseActivity";

    static final String FLICKR_QUERY = "FLICKR_QUERY";
    static final String PHOTO_TRANSFER = "PHOTO_TRANSFER";


}
